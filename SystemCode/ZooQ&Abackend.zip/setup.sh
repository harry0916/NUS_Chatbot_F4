conda create -n safari
conda activate safari
#/anaconda3/bin/pip install -r requirements.txt
/anaconda3/bin/python3 src/app.py
