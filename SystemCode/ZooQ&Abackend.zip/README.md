
## SECTION 1 : PROJECT TITLE

---

## SECTION 2 : EXECUTIVE SUMMARY / PAPER ABSTRACT


---

## SECTION 3 : CREDITS / PROJECT CONTRIBUTION

| Official Full Name  | Student ID (MTech Applicable)  | Work Items (Who Did What) | Email (Optional) |
| :------------ |:---------------:| :-----| :-----|

---

## SECTION 4 : VIDEO OF SYSTEM MODELLING & USE CASE DEMO



---

## SECTION 5 : USER GUIDE


---

## SECTION 6 : PROJECT REPORT / PAPER


## SECTION 7 : MISCELLANEOUS

